import pandas as pd
import ast

# Load your cleaned dataset
df = pd.read_csv("datasets/movie_dataset.csv")

print("\nCOLUMNS:", df.columns.tolist())

# ---- SIMPLE COLUMNS (strings or numbers) ----
simple_columns = [
    "original_language",
    "popularity",
    "imdb_rating",
    "year"
]

for col in simple_columns:
    print(f"\n----- UNIQUE VALUES IN {col.upper()} -----")
    print(df[col].unique()[:50])   # limit for readability

# ---- LIST COLUMNS (need parsing) ----
list_columns = ["genres", "production_countries"]

for col in list_columns:
    print(f"\n----- UNIQUE VALUES IN {col.upper()} -----")

    # Convert string → list
    df[col] = df[col].apply(lambda x: ast.literal_eval(x) if isinstance(x, str) else x)

    unique_items = set()
    for items in df[col]:
        if isinstance(items, list):
            unique_items.update(items)

    print(sorted(unique_items))
